<template>
	<div class="el-loading-mask v-loading">
		<div class="el-loading-spinner">
			<i class="el-icon-loading"></i>
			<p class="el-loading-text">Loading</p>
		</div>
	</div>
</template>
<style>
.v-loading{
	/* background-color: rgba(0, 0, 0, 0.2); */
}
</style>