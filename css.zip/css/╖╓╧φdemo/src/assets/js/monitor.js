const common = {
	linkExceptionHost: 'http://paas.vivo.xyz?url=http://vivo-moni-guan.vivo.xyz/ui/deploy?sys=moninet',
	provinceMap: {
		Beijing: '北京',
		Guangdong: '广东',
		Shanghai: '上海',
		Hebei: '河北',
		Neimenggu: '内蒙古',
		Shandong: '山东',
		Zhejiang: '浙江',
		Jiangsu: '江苏',
		Sichuan: '四川',
		Hubei: '湖北',
		Anhui: '安徽',
		Fujian: '福建',
		Gansu: '甘肃',
		Guangxi: '广西',
		Guizhou: '贵州',
		Hainan: '海南',
		Henan: '河南',
		Heilongjiang: '黑龙江',
		Hunan: '湖南',
		Jilin: '吉林',
		Jiangxi: '江西',
		Liaoning: '辽宁',
		Ningxia: '宁夏',
		Qinghai: '青海',
		Shanxi: '山西',
		Shaanxi: '陕西',
		Tianjing: '天津',
		Tibet: '西藏',
		Xinjiang: '新疆',
		Yunnan: '云南',
		Chongqing: '重庆',
		Macao: '澳门',
		HongKong: '香港',
		Taiwan: '台湾'
	},
	provinceList() {
		let mPList = new Array();
		for (let key in this.provinceMap) {
			let item = {};
			item.label = this.provinceMap[key];
			item.value = key;
			mPList.push(item);
		}
		return mPList;
	},
	provinceFormat(province, type) {
		let val = ''
		if (type == 'en') {
			for (let key in this.provinceMap) {
				if (this.provinceMap[key] == province) {
					val = key
				}
			}
		} else {
			for (let key in this.provinceMap) {
				if (key == province) {
					val = this.provinceMap[key]
				}
			}
		}
		return val || province
	},
	timeAddZero(time) {
		time = time >= 10 ? time : ('0' + time);
		return time;
	},
	formatTime(time, showDay) { // showDay参数标识是否需要展示日期
		let self = this;
		let timeStamp = new Date(time);
		let newTime;
		if (showDay) {
			newTime = self.timeAddZero(timeStamp.getMonth() + 1) + '/' + self.timeAddZero(timeStamp.getDate()) + ' ' + self.timeAddZero(timeStamp.getHours()) + ':' + self.timeAddZero(timeStamp.getMinutes());
		} else {
			newTime = self.timeAddZero(timeStamp.getHours()) + ':' + self.timeAddZero(timeStamp.getMinutes());
		}
		return newTime;
	},
	timeFormat(time, type) {
		let date = new Date(time)
		let yy = date.getFullYear()
		let MM = (date.getMonth() + 1) >= 10 ? (date.getMonth() + 1) : ('0' + (date.getMonth() + 1))
		let dd = date.getDate() >= 10 ? date.getDate() : ('0' + date.getDate())
		let hh = date.getHours() >= 10 ? date.getHours() : ('0' + date.getHours())
		let mm = date.getMinutes() >= 10 ? date.getMinutes() : ('0' + date.getMinutes())
		let ss = date.getSeconds() >= 10 ? date.getSeconds() : ('0' + date.getSeconds())
		if (type == 'yy/MM/dd-hh:mm:ss') {
			return `${yy}/${MM}/${dd}-${hh}:${mm}:${ss}`
		} else if (type == 'hh:mm') {
			return `${hh}:${mm}`
		} else if (type == 'MM/dd hh:mm') {
			return `${MM}/${dd} ${hh}:${mm}`
		} else if (type == 'MM/dd hh:mm') {
			return `${MM}/${dd} ${hh}:${mm}`
		}
	},
	formatLineChartData(originData, columns, toFixedNum = 4) { // toFixedNum参数标识数据保留小数位数
		let rows = [], chartData;
		let selectedTimeLength;
		originData.forEach((item, index) => {
			let obj = {};
			let val = '';
			for (let key in item) {
				if (key !== 'TIME') {
					let keyArr = key.split('-');
					val = parseFloat(item[key]).toFixed(toFixedNum);
					key = keyArr[keyArr.length - 1];
				} else {
					selectedTimeLength = new Date(originData[originData.length - 1].TIME) - new Date(originData[0].TIME)
					if (selectedTimeLength <= 24 * 60 * 60 * 1000) { // 超过一天则x轴只在开头 结尾显示日期
						if (index == 0 || index == originData.length - 1) {
							val = this.timeFormat(item[key], 'MM/dd hh:mm');
						} else {
							val = this.timeFormat(item[key], 'hh:mm');
						}
					} else {
						val = this.formatTime(item[key], true);
					}
				}
				let formatKey = common.provinceFormat(key);
				obj[formatKey] = val;
			}
			rows.push(obj)
		});
		chartData = {
			columns: columns,
			rows: rows
		}
		return chartData;
	},
	provinceGroupOptions: [
		{
			label: '热门省份',
			options: [{
				value: 'Beijing',
				label: '北京'
			}, {
				value: 'Guangdong',
				label: '广东'
			}, {
				value: 'Shanghai',
				label: '上海'
			}]
		},
		{
			label: '省份名称',
			options: [{
				value: 'Hebei',
				label: '河北'
			}, {
				value: 'Neimenggu',
				label: '内蒙古'
			}, {
				value: 'Shandong',
				label: '山东'
			}, {
				value: 'Zhejiang',
				label: '浙江'
			}, {
				value: 'Sichuan',
				label: '四川'
			}]
		}
	],
	allProvincesName: ['北京', '广东', '上海', '河北', '内蒙古', '山东', '浙江', '四川'],
	ispMap: {
		ALL: '所有',
		CMNET: '中国移动',
		UNICOM: '中国联通',
		CHINANET: '中国电信',
		OTHER: '其他'
	},
	ispFormat(isp) {
		let val = ''
		for (let key in this.ispMap) {
			if (key == isp) {
				val = this.ispMap[key]
			}
		}
		return val || isp
	},
	echartsConfig: {
		dataZoom: [
			{
				type: 'inside',
				show: true,
				xAxisIndex: [0],
				start: 0,
				end: 100
			}
		],
		grid: {
			show: false,
			top: 48,
			bottom: 20
		},
		chartHeight: '250px',
	}
}

export default common
