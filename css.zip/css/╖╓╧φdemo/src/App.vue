<template>
    <div id="app"
         class="app">
        <el-container>
            <!-- <el-header v-show="showNav"
                       height="40px">
                <v-nav></v-nav>
            </el-header> -->
            <el-container class="main">
                <router-view></router-view>
            </el-container>
        </el-container>
    </div>
</template>

<script>
import vNav from './components/nav'
export default {
    name: 'App',
    components: {
        vNav
    },
    data() {
        return {
            showNav: false
        }
    },
    created() {
        let referrer = document.referrer;
        let baseUrl = '';
        if (referrer != '') {
            baseUrl = new URL(document.referrer).origin; // iframe外面的地址
        }
        console.log(baseUrl)
        this.showNav = false;
    },
    methods: {
    },
    watch: {
    }
}
</script>

<style lang="less">
  .app{
    .el-header{
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 40px;
      padding: 0;
      z-index: 9;
    }
    .main{
      position: absolute;
      top: 0;
      left: 0;
      right: 0;
      min-height: 100%;
      overflow: auto;
    }
  }
::-webkit-scrollbar {/*滚动条整体样式*/
        width: 8px;     /*高宽分别对应横竖滚动条的尺寸*/
        height: 8px;
    }
::-webkit-scrollbar-thumb {/*滚动条里面小方块*/
        border-radius: 8px;
        //  -webkit-box-shadow: inset 0 0 5px rgba(100,100,100,0.1);
        background: #ddd;
    }
::-webkit-scrollbar-track {/*滚动条里面轨道*/
        // -webkit-box-shadow: inset 0 0 5px rgba(100,100,100,0.1);
        border-radius: 8px;
        background: #fff;
    }
</style>
