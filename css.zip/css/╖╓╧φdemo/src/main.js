// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import 'element-ui/lib/theme-chalk/index.css'
import './assets/css/reset.css'
import router from './router'
import VCharts from 'v-charts'
import ElementUI from 'element-ui';
import axios from 'axios'
import App from './App'

//设置默认请求头
axios.defaults.headers = {
  'X-Requested-With': 'XMLHttpRequest'
}
let referrer = document.referrer;
let baseUrl = '';
if (referrer != '') {
  baseUrl = new URL(document.referrer).origin; // iframe外面的地址
}
axios.interceptors.response.use(res=> {
  let redirectUrl,ssoUrl,requestKey,requestUrl,newRedirectUrl;
  if(res.data.retcode && res.data.retcode==='not_login'){
    if(baseUrl === 'http://base-dev.vivo.xyz' || baseUrl === 'http://paas.vivo.xyz' ){
      let redirectUrlArr = [];
      redirectUrl = res.data.redirect;
      redirectUrlArr = redirectUrl.split('?');
      ssoUrl = redirectUrlArr[0];
      requestKey = redirectUrlArr[1].split('=')[0];
      requestUrl = redirectUrlArr[1].split('=')[1];
      newRedirectUrl = ssoUrl+ '?' + requestKey + '=http://paas.vivo.xyz/?url=' + requestUrl;
      window.top.postMessage({type:'not_login',url:newRedirectUrl},'*');
      return;
    }else{
      // location.href = res.data.redirect
    }
  } else {
    return res
  }
}, err=> {
  return Promise.resolve(err)
})
Vue.prototype.$ajax = axios
// 本地测试时host值应为'/api'，生产上运行时改为空
// Vue.prototype.host = ''
if(process.env.NODE_ENV === 'development'){
  Vue.prototype.host = '/api'
}else{
  Vue.prototype.host = ''
}

Vue.config.productionTip = false
Vue.use(VCharts)
Vue.use(ElementUI);

new Vue({
  el: '#app',
  router,
  template: '<App/>',
  components: { App }
})
