<template>
    <div class="v-date-picker">
        <div class="el-radio-group">
            <label class="el-radio-button el-radio-button--small"
                :class="{'is-active':timeradio==='最近1小时'}"
                @click="timeRadioChange('最近1小时')">
                <span class="el-radio-button__inner">最近1小时</span>
            </label> 
            <label class="el-radio-button el-radio-button--small"
                :class="{'is-active':timeradio==='最近1天'}"
                @click="timeRadioChange('最近1天')">
                <span class="el-radio-button__inner">最近1天</span>
            </label> 
            <label class="el-radio-button el-radio-button--small"
                :class="{'is-active':timeradio==='最近一周'}"
                @click="timeRadioChange('最近一周')">
                <span class="el-radio-button__inner">最近一周</span>
            </label>
        </div>
        <el-date-picker style="width: 320px"
                        :size="size"
                        @change="timeChange"
                        @focus="focus"
                        @blur="blur"
                        v-model="currentTime"
                        format="yyyy-MM-dd HH:mm"
                        type="datetimerange"
                        :picker-options="pickerOptions"
                        range-separator="至"
                        start-placeholder="开始日期"
                        end-placeholder="结束日期"
                        :default-time="['00:00:00', '23:59:59']"
                        :clearable="false">
        </el-date-picker>
    </div>
</template>
<script>
export default {
    name: 'timePicker',
    props: {
        selectTime: '',
        timeRadio: {
            type:String,
            default:''
        },
        size: {
            type:String,
            default:'small'
        }
    },
    data() {
        return {
            timeradio: this.timeRadio,
            currentTime: this.selectTime,
            oldTime:[],
            pickerOptions: {
                disabledDate(time) {
                    return time.getTime() > Date.now();
                }
            },
        }
    },    
    methods: {
        timeRadioChange(radio) {
            const start = new Date()
            const end = new Date()
            switch (radio) {
                case '最近1小时':
                    start.setTime(start.getTime() - 3600 * 1000 * 1)
                    break
                case '最近1天':
                    start.setTime(start.getTime() - 3600 * 1000 * 24)
                    break
                case '最近一周':
                    start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
                    break
            }
            this.timeradio = radio            
            this.currentTime = [start, end]
            this.$emit('refresh', [start, end],radio)
        },
        timeChange(time) {
            if (time) {
                if (time[1] - time[0] <= 0) {
                    this.$message({
                        type: 'warning',
                        message: '开始时间不能小于等于结束时间！'
                    });
                    this.currentTime = this.oldTime
                    return
                }
                if (time[1] - time[0] > 1000 * 60 * 60 * 24 * 30) {
                    this.$message({
                        type: 'warning',
                        message: '时间间隔不能超过30天！'
                    });
                    this.currentTime = this.oldTime
                    return
                }
                if (time[1].getTime() - new Date().getTime() > 0) {
                    this.$message({
                        type: 'warning',
                        message: '结束时间不能大于当前时间！'
                    });
                    this.currentTime = this.oldTime
                    return
                }
                console.log(this.timeradio)
                this.timeradio = ''
                this.$emit('refresh', time,'');
            }
        },
        blur(time){
            this.$emit('blur', time.value);
        },
        focus(time){
            this.oldTime = time.value
            this.$emit('focus', time.value);
        },
    },
    watch: {
        selectTime() {
            this.currentTime = this.selectTime;
        },
        timeRadio() {
            this.timeradio = this.timeRadio;
        },
    }
}
</script>
<style lang="less">
.v-date-picker {
    display: inline-block;
    .is-active{
        .el-radio-button__inner{
            color: #fff;
            background-color: #409EFF;
            border-color: #409EFF;
            box-shadow: -1px 0 0 0 #409EFF;
        }
    }
    .el-range__close-icon{
        display: none;
    }
    .el-date-editor {
        vertical-align: middle;
    }
}
</style>
