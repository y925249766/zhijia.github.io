<template>
    <div class="header">        
        <el-menu
          :default-active="activeIndex"
          class="el-menu-demo"
          mode="horizontal"
          @select="handleSelect"
          background-color="#545c64"
          text-color="#fff"
          active-text-color="#ffd04b">
            <template v-for="(item) in navData">
                <!--<el-submenu v-if="item.paths&&item.application=='CMDB'" :index="item.application">
                    <template slot="title">{{item.application}}</template>
                    <el-menu-item v-for="(subItem,n) in item.paths" :key="n" :index="subItem.path">{{subItem.name}}</el-menu-item>
                </el-submenu>

                <el-submenu v-if="item.paths&&item.application!='CMDB'" :index="item.application">
                    <template slot="title">{{item.application}}</template>
                    <el-menu-item v-for="(subItem,n) in item.paths" :key="n" :index="subItem.path">
                        <a :href="item.domain+subItem.path">{{subItem.name}}</a>
                    </el-menu-item>
                </el-submenu> -->

                <el-submenu :index="item.application">
                    <template slot="title">{{item.application}}</template>
                    <el-menu-item v-for="(subItem,n) in item.paths" :key="n" :index="subItem.path">
                        <a :href="item.domain+subItem.path">{{subItem.name}}</a>
                    </el-menu-item>
                </el-submenu>
            </template>
          <a style="color: #fff;line-height: 40px;text-decoration: none;position: absolute;left: 230px;font-size:14px;padding: 0 5px" href="http://paas.vivo.xyz/?url=http%3A%2F%2Fvivo-moni-net-cha.vivo.xyz">新平台入口</a>
            <!--<el-submenu :index="'xxx'">
                <template slot="title">监控系统</template>
                <el-menu-item :index="'/ui/network'">域名拨测数据查询</el-menu-item>
                <el-menu-item :index="''">
                    <a href="http://vivo-moni-cha.vivo.xyz">CDN访问质量实时大盘</a>
                </el-menu-item>
                <el-menu-item :index="''">
                    <a href="http://vivo-moni-cha.vivo.xyz/ui/contrast?domain=dl.gamecenter.vivo.com.cn&isp=CHINANET&metric=successRate">CDN访问质量实时查询</a>
                </el-menu-item>
                <el-menu-item :index="''">
                    <a href="http://vivo-moni-cha.vivo.xyz/ui/trend?domain=dl.gamecenter.vivo.com.cn&isp=CHINANET&metric=successRate&cdn=ws%7Ctx%7Cbs%7Cwr%7Cqn&province=Guangdong">CDN访问质量历史趋势</a>
                </el-menu-item>
                <el-menu-item :index="''">
                    <a href="http://vivo-moni-browser-cha.vivo.xyz">浏览器连通率实时大盘</a>
                </el-menu-item>
                <el-menu-item :index="''">
                    <a href="http://vivo-moni-guan.vivo.xyz">异常检测规则列表</a>
                </el-menu-item>
                <el-menu-item :index="''">
                    <a href="http://vivo-moni-net-guan.vivo.xyz">域名拨测任务配置</a>
                </el-menu-item>
                <el-menu-item :index="''">
                    <a href="http://alarmadmin.vivo.xyz/alarm.html">告警中心</a>
                </el-menu-item>
            </el-submenu> -->
            <!-- <el-submenu class="changelog" :index="'help'" popper-class="quit">
                <template slot="title">帮助</template>
                <el-menu-item :index="''"><a href="http://km.vivo.xyz/pages/viewpage.action?pageId=14502573">Changelog</a></el-menu-item>
                <el-menu-item :index="''"><a href="http://km.vivo.xyz/pages/viewpage.action?pageId=14500237">使用手册</a></el-menu-item>
                <el-menu-item :index="''">版本号: 2.3.1</el-menu-item>
            </el-submenu> -->
            <el-submenu  class="user-info" :index="'quit'" popper-class="quit">
                <template slot="title">
                    {{userInfo.userName}}
                </template>
                <!-- <template slot="title">
                    <el-badge v-if="todoNum>0" is-dot>{{userInfo.userName}}</el-badge>
                    <span v-if="todoNum==0">{{userInfo.userName}}</span>
                </template>
                <el-menu-item :index="'/ui/myrole'">我的权限</el-menu-item>
                <el-menu-item :index="'/ui/workorderlist_mytodo'">我的待办<el-badge v-if="todoNum>0" :value="todoNum" /></el-menu-item>
                <el-menu-item :index="'/ui/workorderlist_mycreate'">我的发起</el-menu-item>
                <el-menu-item :index="'/ui/workorderlist_myreviewed'">我的参与</el-menu-item> -->
                <el-menu-item :index="'quit'"><a :href="host+'/net/cha/logout'">退出</a></el-menu-item>
            </el-submenu>
        </el-menu>
        <div class="v-logo">基础技术平台</div>        
    </div>
</template>

<script>
export default {
  	name: 'v-nav',
	data () {
    	return {
            navData:[],
      		activeIndex: 'http://vivo-moni-net-cha.vivo.xyz',
            userInfo:{}
    	}
  	},  	   
    watch:{
　　      $route(to){          
            //this.activeIndex = this.$route.path || 'http://vivo-moni-net-cha.vivo.xyz'
        }
　　  },
    computed: {        
        currentNode() {
            return this.$store.state.currentNode
        } 
    },
    created () {
        //this.activeIndex = this.$route.path || 'http://vivo-moni-net-cha.vivo.xyz'
        this.getUserInfo()
        this.getNav()
    },
  	methods: {        
        getUserInfo(){
            let self = this
            this.$ajax({
                method:'get',
                url:`${this.host}/net/cha/currentUser`,
            }).then(function (res) {
                if(res.status == 200){
                    self.userInfo = res.data
                    self.getNav()
                }
            }).catch(function (error) {
                console.log(error);
            });
        },
        
        getNav(){
            let self = this
            this.$ajax({
                method:'get',
                url:`${this.host}/net/cha/cmdbmenu`
            }).then(function (res) {
                if(res.status == 200){
                    if(res.data.code == 0){
                        self.navData = res.data.data.menus
                    }
                }
            }).catch(function (error) {
                console.log(error);
            });
        },    
      	handleSelect(key) {
            this.$router.push({path:key})            
      	}        
    }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="less">
.header{
    height: 40px;
    background-color: rgb(84, 92, 100);
    .v-logo{
        position: absolute;
        top: 0;
        left: 0;
        width: 240px;
        height: 40px;
        line-height: 40px;
        text-align: center;
        color: rgb(255, 208, 75);
        font-size: 22px;
    }    
    .user-info{
        position: absolute;
        right: 20px;
        top: 0;
        width: 128px;
        height: 40px;
        color: #fff;
        .el-menu{
            padding: 0;
            .el-submenu__title{
                i{
                    color: #fff;
                }
            }
        }
    }
    .el-menu{
        height: 40px;
        padding-left: 320px;
        .changelog{
            position: absolute;
            right: 150px;
        }
        .el-badge{
            .el-badge__content.is-fixed.is-dot{
                right: 0px;
                top: 10px;
                border: none;
            }
        }
    }
    .el-menu--horizontal .el-menu-item{
        height: 40px;
        line-height: 40px;
    }
    .el-menu--horizontal .el-submenu .el-submenu__title{
        height: 40px;
        line-height: 40px;
    }
    .el-menu--horizontal .el-submenu>.el-menu{
        top: 40px;
    }
    .el-submenu .el-menu-item{
        min-width: 0;
    }
    .el-menu--popup{
        padding: 0;
    }
}  
.el-menu--popup-bottom-start,
.el-menu--popup-right-start {
    margin: 0 !important;
}
.el-menu-item{
    &.is-active{
        a{
            color: rgb(255, 208, 75) !important;
        }
    }
    a{
        display: block;
        color: #fff;
        text-decoration: none;
    }
    .el-badge__content{
        border: none;
    }
}
.quit{
    .el-menu--popup{
        width: 120px;
        min-width:0;
    }
}  
</style>
