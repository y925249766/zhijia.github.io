<template>
  <div style="padding: 50px">
    <div class="section1 horizontal-mode">
      <h4>咏柳</h4>
      <p>碧玉妆成一树高，<br>万条垂下绿丝绦。<br>不知细叶谁裁出，<br>二月春风似剪刀。</p>
    </div>
    <div class="vertical-mode">
      <h4>咏柳</h4>
      <p>碧玉妆成一树高，<br>万条垂下绿丝绦。<br>不知细叶谁裁出，<br>二月春风似剪刀。</p>
    </div>
    <div class="section2">
      vertical-rl表示文本是垂直方向(vertical)展示，然后阅读的顺序是从右往左(rl:right-left)，跟我们古诗的阅读顺序一致。
      vertical-lr表示文本是垂直方向(vertical)展示，然后阅读的顺序还是默认的从左往右(lr:left-right)，也就是仅仅是水平变垂直。

      <h2>vertical-lr:</h2>

      <p class="vertical-lr">
        深圳壹方中心<br/>
        互联网基础平台
      </p>
      <h2>vertical-rl:</h2>

      <p class="vertical-rl">
        深圳壹方中心<br/>
        互联网基础平台
      </p>

      <h2>英文 vertical-lr:</h2>
      <p class="vertical-lr">
        Example text1<br/>
        Example text2
      </p>

      <h2>英文 vertical-rl:</h2>
      <p class="vertical-rl">
        Example text1<br/>
        Example text2
      </p>

      <h2>英文修复版 vertical-lr:</h2>
      <p class="vertical-lr-fixed">
        Example text1<br/>
        Example text2
      </p>
    </div>

    <div class="section3">
      <h2>writing-mode结合text-indent实现文字下沉效果</h2>

      <p>恭喜你中了88元红包！</p>
      <a href="javascript:" class="btn vertical-mode">领到</a>
      <a href="javascript:" class="btn2">领到</a>
      <h2>text-indent定义 from MDN</h2>
      <p class="text-indent">text-indent 属性 规定了 一个元素 首行 文本内容之前应该有多少水平空格。水平空格是块级包含元素的内容盒子的左边(对于从右向左布局来说是右边).</p>
    </div>
  </div>
</template>

<script>
  export default {
    name: 'writingMode',
    components: {
    },
    data() {
      return {
      }
    },
    watch: {
    },
    created() {
    },
    mounted() {

    },
    methods: {
    }
  }
</script>
<style lang="less">
  *{
    line-height: 1.3;
  }
  .horizontal-mode{
    line-height: 1.5;
  }
  .vertical-mode {
    margin-top: 60px;
    font-family: Arial, sans-serif;
    line-height: 1.5;
    writing-mode: vertical-rl;
  }
  h2{margin-top: 10px}
  .section2{
    margin-top: 50px;
    .vertical-lr{
      writing-mode: vertical-lr;
    }
    .vertical-rl{
      writing-mode: vertical-rl;
    }
    .vertical-lr-fixed{
      writing-mode: vertical-lr;
      text-orientation:upright
    }
  }

  .section3{
    /*文字下沉效果*/
    .btn, .btn2 {
      display: block;
      color: #a78252;
      background-color: #ddc390;
      width: 85px; height: 85px;
      text-decoration: none;
      line-height: 85px;
      border: 6px solid #ddc390;
      border-radius: 50%;
      box-shadow: inset 0 0 0 1px #d6b681, 0 1px, 0 2px, 0 3px, 0 4px;
      text-align: center;
      -webkit-transition: border-color .25s, background-color .25s;
      transition: border-color .25s, background-color .25s;
      font-size: 22px;
      cursor: pointer;
    }
    .btn:active {
      text-indent: 5px;
    }
    .btn2:active {
      line-height: 90px;
    }
  }

</style>
